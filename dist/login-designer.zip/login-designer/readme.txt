=== Login Designer ===
Author URI: https://thatplugincompany.com
Plugin URI: https://logindesigner.com
Contributors: ThatPluginCompany, richtabor
Donate link: https://logindesigner.com
Tags: login, custom login, customize wordpress login, wordpress login, customizer, custom admin, login logo, logo, login customizer
Requires at least: 4.7
Tested up to: 4.9
Requires PHP: 5.2.4
Stable tag: 0.0.5
License: GPL-3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html

The easiest way to completly customize your WordPress login page. Create stunning login templates in seconds with the most beautiful and elegant login customizer WordPress plugin.

== Description ==

Learn more at [logindesigner.com](https://logindesigner.com?utm_medium=login-designer-lite&utm_source=readme&utm_campaign=readme&utm_content=learn-more).

== Installation ==

1. Upload the `login-designer` folder to your `/wp-content/plugins/` directory or alternatively upload the login-designer.zip file via the plugin page of WordPress by clicking 'Add New' and selecting the zip from your local computer.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Customize your login page from the WordPress Customizer > Login Designer section.

== Screenshots ==

1.

== Changelog ==

= 1.0 =
* Initial upload.

== Upgrade Notice ==

= 1.0 =
Initial upload. Enjoy!
