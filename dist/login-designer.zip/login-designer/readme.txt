=== Login Designer ===
Author URI: https://thatplugincompany.com
Plugin URI: https://logindesigner.com
Contributors: ThatPluginCompany, richtabor
Donate link: https://logindesigner.com
Tags: login, custom login, customize wordpress login, wordpress login, customizer, custom admin, login logo, logo, login customizer
Requires at least: 4.7
Tested up to: 4.9
Requires PHP: 5.2.4
Stable tag: 1.0.0
License: GPL-3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html

The easiest way to completly customize your WordPress login page. Create stunning login templates in seconds with the most beautiful and elegant login customizer WordPress plugin.




== Description ==

While Login Designer [logindesigner.com](https://logindesigner.com?utm_medium=login-designer-lite&utm_source=readme&utm_campaign=readme&utm_content=login-designer) is not the first WordPress plugin designed for custom login editing, it clearly offers an unparalleled live-editing experience. I’ve developed new methods and techniques which make Login Designer’s customizing experience the best in class — by a long shot.

Zero refreshes. Contextually displayed options and plugin settings. Custom event triggers. Context-aware previews. Powerful custom controls. Live editing... the list goes on.

All in all, Login Designer is a UX beast. It’s familiar, yet completely revolutionary.

Click on any element on your login page to fine tune it. That element’s settings are contextually displayed, while other’s hide. You'll spend less time navigating the Customizer’s sections and panels, and more time actually fine-tuning your website's login page. Winning.

Intrigued? I bet you are.

Once you try Login Designer, every other Customizer experience will feel lackluster. Guaranteed.




= Get started today =

Installation is free, fun, quick, and easy. Set up Login Desiger in minutes.

= Built with developers in mind =
Extensible, adaptable, and open source — Login Designer is created with developers in mind. There are opportunities for developers at all levels to contribute. [Click here](https://github.com/thatplugincompany/login-designer) to contribute to Login Designer.


== Installation ==

1. Upload the `login-designer` folder to your `/wp-content/plugins/` directory or alternatively upload the login-designer.zip file via the plugin page of WordPress by clicking 'Add New' and selecting the zip from your local computer.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Customize your login page from the WordPress Customizer > Login Designer section.




== Screenshots ==

1.




== Frequently Asked Questions ==

= How do I start customizing my login page? =

You may easily navigate to the Login Designer editor via the WordPress Dashboard > Apperance > Login link. Alternatively, you may view the editor by opening the "Login Designer" section within the Customizer.

= Is Login Designer Free? =

Yes! Login Designer's core features are and always will be free.

= What themes work with Login Designer? =

Any properly developed WordPress theme will work with Login Designer. If you're looking for exceptional themes for creative folks, check out [ThemeBeans](https://logindesigner.com?utm_medium=login-designer-lite&utm_source=readme&utm_campaign=readme&utm_content=themebeans).

= Is Login Designer translatable? =

Yes! Login Design is deployed with full translation and localization support via the 'login-designer' text-domain.

= Where can I ask for help? =

Please reach out via the official [plugin support forum](https://wordpress.org/support/plugin/login-designer).



== Changelog ==

= 1.0.0 =
* Initial upload. Enjoy!
