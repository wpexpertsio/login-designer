=== Login Designer ===
Author URI: https://logindesigner.com
Plugin URI: https://logindesigner.com
Contributors: richtabor
Donate link: https://logindesigner.com
Tags: login, logo, custom logo, customizer
Requires at least: 4.7
Tested up to: 4.9
Requires PHP: 5.2.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

The simplest way to beautify your website's login form with the WordPress Customizer.


== Description ==

Learn more at [logindesigner.com](https://logindesigner.com?utm_source=home&utm_medium=description_tab&utm_content=home&utm_campaign=readme).


== Installation ==

1. Upload the `wp-gravatar-logo` folder to your `/wp-content/plugins/` directory or alternatively upload the login-designer.zip file via the plugin page of WordPress by clicking 'Add New' and selecting the zip from your local computer.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Customize the size and email for your Gravatar logo via the Customizer > Login Designer section.

== Screenshots ==

1.

== Changelog ==

= 1.0 =
* Initial upload.

== Upgrade Notice ==

= 1.0 =
Initial upload. Enjoy!
