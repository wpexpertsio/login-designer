<?php
/**
 * Settings Customizer Section.
 *
 * @package   Login Designer
 * @copyright @@pkg.copyright
 * @author    ThemeBeans <hello@themebeans.com>
 * @license   http://www.gnu.org/licenses/gpl-2.0.html GNU Public License
 */

/**
 * Settings Section.
 */

$wp_customize->add_setting( 'login_designer[login_redirect]', array(
	'default'               => $defaults['login_redirect'],
	'type' 			=> 'option',
	'transport'         	=> 'postMessage',
	'sanitize_callback' 	=> 'absint',
) );

$wp_customize->add_control( 'login_designer[login_redirect]', array(
	'label'          	=> esc_html__( 'Login Redirect', 'login-designer' ),
	'section'        	=> 'login_designer__section--settings',
	'type'           	=> 'dropdown-pages',
	'allow_addition'	=> true,
) );

$wp_customize->add_setting( 'login_designer[logout_redirect]', array(
	'default'               => $defaults['logout_redirect'],
	'type' 			=> 'option',
	'transport'         	=> 'postMessage',
	'sanitize_callback' 	=> 'absint',
) );

$wp_customize->add_control( 'login_designer[logout_redirect]', array(
	'label'          	=> esc_html__( 'Logout Redirect', 'login-designer' ),
	'section'        	=> 'login_designer__section--settings',
	'type'          	=> 'dropdown-pages',
	'allow_addition' 	=> true,
) );

$wp_customize->add_setting( 'login_designer[login_message]', array(
	'default'               => $defaults['login_message'],
	'type' 			=> 'option',
	// 'transport'         	=> 'postMessage',
	'sanitize_callback' 	=> 'esc_textarea',
) );

$wp_customize->add_control( 'login_designer[login_message]', array(
	'label'          	=> esc_html__( 'Login Message', 'login-designer' ),
	'section'        	=> 'login_designer__section--settings',
	'type'           	=> 'textarea',
) );
