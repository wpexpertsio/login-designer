<?php
/**
 * Templates Customizer Section.
 *
 * @package   Login Designer
 * @copyright @@pkg.copyright
 * @author    ThemeBeans <hello@themebeans.com>
 * @license   http://www.gnu.org/licenses/gpl-2.0.html GNU Public License
 */

$wp_customize->add_setting( 'login_designer[template]', array(
	'default'               => $defaults['template'],
	'type' 			=> 'option',
	// 'transport'             => 'postMessage',
) );

$wp_customize->add_control( new Login_Designer_Template_Control( $wp_customize, 'login_designer[template]', array(
	'type'                  => 'login-designer-template-selector',
	'description'           => esc_html__( 'You can switch templates at any time. Previewing a template allows you to make style changes without changing the live template visitors see.', 'login-designer' ),
	'section'               => 'login_designer__section--templates',
	'choices'               => $this->get_choices( $this->get_templates() ),
) ) );
