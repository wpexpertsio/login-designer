********************************************************

  Login Designer I18n
  ============================

  Do not put custom translations here. They will be deleted
  on Login Designer updates.

  Keep custom Login Designer translations in /wp-content/languages/login-designer/

  You want to translate, help, or improve a translation.

  Join our WP-Translations Community at
  https://www.transifex.com/projects/p/login-designer/

  More info at http://wp-translations.org/

********************************************************
